package cams.inv.service.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Exception class to handle Runtime Resource Not Found Cases
 *
 */
@ResponseStatus(HttpStatus.NOT_FOUND)
public class ResourceNotFoundException extends RuntimeException {
	/**
	* 
	*/
	private static final long serialVersionUID = -3085551621741997176L;

	public ResourceNotFoundException(String msg) {
		super(msg);
	}
}
