package cams.inv.service.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

/**
 * DTO for Order Item Request
 *
 */
public record OrderItemRequest(@NotNull String sku, @NotNull @Min(0) Integer quantity) {
}
