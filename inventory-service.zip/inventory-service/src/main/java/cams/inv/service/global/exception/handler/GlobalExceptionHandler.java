package cams.inv.service.global.exception.handler;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import cams.inv.service.constants.InventoryConstants;
import cams.inv.service.exception.InsufficientStockException;
import cams.inv.service.exception.ResourceModificationException;
import cams.inv.service.exception.ResourceNotFoundException;

/**
 * Global Exception Handler for Inv Management Service
 *
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

	// Handle DataIntergrityViolationException
	@ExceptionHandler(DataIntegrityViolationException.class)
	public ResponseEntity<Map<String, String>> handleDataIntegrityViolation(DataIntegrityViolationException ex) {
		Map<String, String> response = new HashMap<>();
		response.put(InventoryConstants.ERROR, InventoryConstants.DB_CONSTRAINT_VIOLATED);
		response.put(InventoryConstants.DETAILS, ex.getMostSpecificCause().getMessage());
		return ResponseEntity.status(HttpStatus.CONFLICT).body(response);
	}

	// Handle MethodArgumentNotValidException
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<Map<String, String>> handleValidationErrors(MethodArgumentNotValidException ex) {
		Map<String, String> response = ex.getBindingResult().getFieldErrors().stream()
				.collect(Collectors.toMap(e -> e.getField(), e -> e.getDefaultMessage(), (a, b) -> a));
		return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
	}

	// Handle ResourceNotFoundException, InsufficientStockException,
	@ExceptionHandler({ ResourceNotFoundException.class, InsufficientStockException.class })
	public ResponseEntity<Map<String, String>> handleNotFound(RuntimeException ex) {
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of(InventoryConstants.ERROR, ex.getMessage()));
	}

	// Handle ResourceModificationException
	@ExceptionHandler(ResourceModificationException.class)
	public ResponseEntity<Map<String, String>> handleNotModified(RuntimeException ex) {
		Map<String, String> map = Map.of(InventoryConstants.ERROR, ex.getMessage());
		return ResponseEntity.status(HttpStatus.CONFLICT).body(map);
	}

	// Handle any Exception
	@ExceptionHandler(Exception.class)
	public ResponseEntity<Map<String, String>> handleAny(Exception ex) {
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
				.body(Map.of(InventoryConstants.ERROR, HttpStatus.INTERNAL_SERVER_ERROR.toString()));
	}

	// Handle OptimisticLockingFailureException
	@ExceptionHandler(OptimisticLockingFailureException.class)
	public ResponseEntity<Map<String, String>> handleOptimistic(OptimisticLockingFailureException ex) {
		return ResponseEntity.status(HttpStatus.CONFLICT)
				.body(Map.of(InventoryConstants.ERROR, InventoryConstants.RESOURCE_CONFLICT_ERR_MSG));
	}

}
