package cams.inv.service.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

/**
 * DTO for OrderResponse
 *
 */
public record OrderResponse(Long id, LocalDateTime orderDate, String status, List<OrderItemResponse> items,
		BigDecimal total) {
	public record OrderItemResponse(Long productId, String sku, String name, Integer quantity, BigDecimal unitPrice) {
	}
}
