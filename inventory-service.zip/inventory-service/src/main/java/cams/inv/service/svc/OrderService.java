package cams.inv.service.svc;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cams.inv.service.constants.InventoryConstants;
import cams.inv.service.constants.OrderStatus;
import cams.inv.service.dto.OrderItemRequest;
import cams.inv.service.dto.OrderRequest;
import cams.inv.service.dto.OrderResponse;
import cams.inv.service.dto.ProductSummary;
import cams.inv.service.dto.OrderResponse.OrderItemResponse;
import cams.inv.service.exception.InsufficientStockException;
import cams.inv.service.exception.ResourceModificationException;
import cams.inv.service.exception.ResourceNotFoundException;
import cams.inv.service.model.Order;
import cams.inv.service.model.OrderItem;
import cams.inv.service.model.Product;
import cams.inv.service.repo.OrderRepository;
import cams.inv.service.repo.ProductRepository;
import jakarta.transaction.Transactional;

/**
 * Service Layer for Order
 *
 */
@Service
public class OrderService {

	private static final Logger log = LoggerFactory.getLogger(OrderService.class);

	@Autowired
	private OrderRepository orderRepository;

	@Autowired
	private ProductRepository productRepository;

	@Transactional
	public OrderResponse create(OrderRequest orderReq) {
		Order order = new Order();
		order.setOrderDate(LocalDateTime.now());
		order.setStatus(OrderStatus.PENDING);
		for (OrderItemRequest orderItemReq : orderReq.items()) {
			Product product = productRepository.findBySku(orderItemReq.sku()).orElseThrow(
					() -> new ResourceNotFoundException(InventoryConstants.PRODUCT_NOT_FOUND + orderItemReq.sku()));
			if (product.getStock() < orderItemReq.quantity()) {
				throw new InsufficientStockException(InventoryConstants.INSUFFICIENT_STOCK + product.getSku());
			}
			product.reduceStock(orderItemReq.quantity());
			productRepository.save(product);

			OrderItem orderItem = new OrderItem();
			orderItem.setProduct(product);
			orderItem.setQuantity(orderItemReq.quantity());
			log.info("orderitem " + orderItem);

			order.addItem(orderItem);
			order.setStatus(OrderStatus.COMPLETED);
		}
		Order savedOrder = orderRepository.save(order);
		return convertToOrderResponse(savedOrder);
	}

	private OrderResponse convertToOrderResponse(Order order) {
		List<OrderItemResponse> items = order.getItems().stream()
				.map(item -> new OrderItemResponse(item.getProduct().getId(), item.getProduct().getSku(),
						item.getProduct().getName(), item.getQuantity(), item.getProduct().getPrice()))
				.collect(Collectors.toList());
		BigDecimal total = items.stream().map(it -> it.unitPrice().multiply(BigDecimal.valueOf(it.quantity())))
				.reduce(BigDecimal.ZERO, BigDecimal::add);
		return new OrderResponse(order.getId(), order.getOrderDate(), order.getStatus().name(), items, total);
	}

	public void updateOrderStatus(Long orderId, OrderStatus newStatus) {
		Order order = orderRepository.findById(orderId)
				.orElseThrow(() -> new ResourceNotFoundException(InventoryConstants.ORDER_NOT_FOUND));
		log.info("Order Status : " + order.getStatus());
		if (order.getStatus().equals(OrderStatus.PENDING)) {
			order.setStatus(newStatus);
			orderRepository.save(order);
		} else {
			throw new ResourceModificationException(
					"Order cannot be changed from " + order.getStatus() + " to " + newStatus);
		}
	}

	public List<ProductSummary> summarizeTotalPerProduct() {
		return orderRepository.findAll().stream().flatMap(order -> order.getItems().stream())
				.collect(Collectors.groupingBy(oi -> oi.getProduct(),
						Collectors.summingDouble(oi -> oi.getProduct().getPrice().doubleValue() * oi.getQuantity())))
				.entrySet().stream().map(e -> new ProductSummary(e.getKey().getId(), e.getKey().getSku(),
						e.getKey().getName(), BigDecimal.valueOf(e.getValue())))
				.collect(Collectors.toList());
	}

}
