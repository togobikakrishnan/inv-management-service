package cams.inv.service.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Exception class to handle Runtime Resource Modification Exception Cases
 *
 */
@ResponseStatus(HttpStatus.CONFLICT)
public class ResourceModificationException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 319233160825176645L;

	public ResourceModificationException(String msg) {
		super(msg);
	}

}
