package cams.inv.service.exception;

/**
 * Exception class to handle Runtime Insufficient Stock Cases
 *
 */
public class InsufficientStockException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5159745797517310473L;

	public InsufficientStockException(String msg) {
		super(msg);
	}

}
