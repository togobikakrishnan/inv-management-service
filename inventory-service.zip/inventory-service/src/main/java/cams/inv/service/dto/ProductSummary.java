package cams.inv.service.dto;

import java.math.BigDecimal;

/**
 * DTO for Product Summary
 *
 */
public record ProductSummary(Long id, String sku, String name, BigDecimal totalValue) {

}
