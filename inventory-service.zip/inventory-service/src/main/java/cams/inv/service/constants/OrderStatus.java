package cams.inv.service.constants;

/**
 * OrderStatus is an enum having PENDING, COMPLETE, CANCELLED status
 *
 */
public enum OrderStatus {
	PENDING, COMPLETED, CANCELLED
}
