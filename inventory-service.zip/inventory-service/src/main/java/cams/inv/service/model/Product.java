package cams.inv.service.model;

import java.math.BigDecimal;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import jakarta.persistence.Version;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;

/**
 * Product model - id (auto-generated), name (String, required), sku (String,
 * unique), price (BigDecimal), stock (Integer, non-negative).
 *
 */
@Entity
@Table(name = "product", uniqueConstraints = { @UniqueConstraint(columnNames = "sku") })
public class Product {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "product_id")
	private long id;

	@NotBlank(message = "Product name is required")
	@Column(name = "product_name", nullable = false)
	private String name;

	@NotBlank(message = "SKU is required")
	@Column(name = "sku", nullable = false, unique = true)
	private String sku;

	@DecimalMin(value = "0.0", inclusive = false, message = "Price must be greater than 0")
	@Column(name = "price", nullable = false)
	private BigDecimal price;

	@Min(value = 0, message = "Stock cannot be negative")
	@Column(name = "stock", nullable = false)
	private Integer stock;

	@Version
	private Integer version;

	public void reduceStock(int quantity) {
		if (stock < quantity) {
			throw new IllegalArgumentException("Insufficient stock for product " + name);
		}
		stock -= quantity;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public Integer getStock() {
		return stock;
	}

	public void setStock(Integer stock) {
		this.stock = stock;
	}

	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", sku=" + sku + ", price=" + price + ", stock=" + stock + "]";
	}

}
