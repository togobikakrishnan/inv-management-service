package cams.inv.service.constants;

/**
 * Class to hold all constant strings
 *
 */
public interface InventoryConstants {

	String ERROR = "Error";

	String DETAILS = "Details";

	String DB_CONSTRAINT_VIOLATED = "Database constraint violated";

	String RESOURCE_CONFLICT_ERR_MSG = "Conflict - resource modified by another transaction. Retry.";

	String INSUFFICIENT_STOCK = "Insufficient stock for product ";

	String PRODUCT_NOT_FOUND = "Product not found ";

	String ORDER_NOT_FOUND = "Order not found";

}
