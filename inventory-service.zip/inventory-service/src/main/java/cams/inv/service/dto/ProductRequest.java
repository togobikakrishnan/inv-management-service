package cams.inv.service.dto;

import java.math.BigDecimal;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

/**
 * DTO for ProductRequest
 *
 */
public record ProductRequest(@NotBlank String name, @NotBlank String sku,
		@NotNull @DecimalMin(value = "0.0", inclusive = false) BigDecimal price, @NotNull @Min(0) Integer stock) {
}
