package cams.inv.service.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cams.inv.service.dto.ProductRequest;
import cams.inv.service.dto.ProductResponse;
import cams.inv.service.svc.ProductService;
import jakarta.validation.Valid;

/**
 * Product Controller has the REST end points for all product related services
 *
 */
@RestController
@RequestMapping("/api/products")
public class ProductController {

	@Autowired
	private ProductService productService;

	@PostMapping
	public ResponseEntity<ProductResponse> create(@Valid @RequestBody ProductRequest productReq) {
		return ResponseEntity.status(HttpStatus.CREATED).body(productService.create(productReq));
	}

	@GetMapping
	public ResponseEntity<List<ProductResponse>> listAll() {
		List<ProductResponse> allProducts = productService.findAll();
		if (allProducts != null && !allProducts.isEmpty()) {
			return ResponseEntity.status(HttpStatus.OK).body(allProducts);
		}
		return ResponseEntity.status(HttpStatus.NO_CONTENT).body(allProducts);
	}

	@GetMapping("/lowStock/{threshold}")
	public ResponseEntity<List<ProductResponse>> lowStock(@PathVariable int threshold) {
		List<ProductResponse> lowStockProducts = productService.findLowStock(threshold);
		if (lowStockProducts != null && !lowStockProducts.isEmpty()) {
			return ResponseEntity.status(HttpStatus.OK).body(lowStockProducts);
		}
		return ResponseEntity.status(HttpStatus.NO_CONTENT).body(lowStockProducts);
	}

	@GetMapping("/{sku}")
	public ResponseEntity<ProductResponse> get(@PathVariable String sku) {
		return ResponseEntity.status(HttpStatus.OK).body(productService.findBySku(sku));
	}

	@PutMapping
	public ResponseEntity<ProductResponse> update(@Valid @RequestBody ProductRequest productReq) {
		return ResponseEntity.ok(productService.update(productReq));
	}

}
