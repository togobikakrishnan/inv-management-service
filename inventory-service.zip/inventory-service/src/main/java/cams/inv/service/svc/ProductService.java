package cams.inv.service.svc;

import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cams.inv.service.constants.InventoryConstants;
import cams.inv.service.dto.ProductRequest;
import cams.inv.service.dto.ProductResponse;
import cams.inv.service.exception.ResourceNotFoundException;
import cams.inv.service.model.Product;
import cams.inv.service.repo.ProductRepository;

/**
 * Business Logic for Product
 *
 */
@Service
public class ProductService {

	private static final Logger log = LoggerFactory.getLogger(ProductService.class);

	@Autowired
	private ProductRepository productRepository;

	public ProductResponse create(ProductRequest productReq) {
		Product product = new Product();
		product.setName(productReq.name());
		product.setPrice(productReq.price());
		product.setSku(productReq.sku());
		product.setStock(productReq.stock());
		Product savedProduct = productRepository.save(product);
		return convertToDTO(savedProduct);
	}

	public List<ProductResponse> findAll() {
		return productRepository.findAll().stream().map(this::convertToDTO).collect(Collectors.toList());
	}

	public List<ProductResponse> findLowStock(int threshold) {
		List<Product> allProducts = productRepository.findAll();
		log.info("allProducts : " + allProducts);
		if (allProducts != null && !allProducts.isEmpty()) {
			return allProducts.stream().filter(product -> product.getStock() < threshold).map(this::convertToDTO)
					.collect(Collectors.toList());
		}
		return null;
	}

	public ProductResponse findBySku(String sku) {
		Product product = productRepository.findBySku(sku)
				.orElseThrow(() -> new ResourceNotFoundException(InventoryConstants.PRODUCT_NOT_FOUND + sku));
		return convertToDTO(product);
	}

	public ProductResponse update(ProductRequest productReq) {
		Product product = productRepository.findBySku(productReq.sku()).orElseThrow(
				() -> new ResourceNotFoundException(InventoryConstants.PRODUCT_NOT_FOUND + productReq.sku()));
		product.setName(productReq.name());
		product.setPrice(productReq.price());
		product.setStock(productReq.stock());
		return convertToDTO(productRepository.save(product));
	}

	private ProductResponse convertToDTO(Product p) {
		return new ProductResponse(p.getId(), p.getName(), p.getSku(), p.getPrice(), p.getStock());
	}

}
