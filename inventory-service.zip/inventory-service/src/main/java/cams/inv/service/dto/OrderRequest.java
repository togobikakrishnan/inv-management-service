package cams.inv.service.dto;

import java.util.List;

import jakarta.validation.constraints.NotEmpty;

/**
 * DTO for Order Request
 *
 */
public record OrderRequest(@NotEmpty List<OrderItemRequest> items) {

}
