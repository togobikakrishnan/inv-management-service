package cams.inv.service.dto;

import java.math.BigDecimal;

/**
 * DTO for Product Response
 *
 */
public record ProductResponse(Long id, String name, String sku, BigDecimal price, Integer stock) {

}
