package cams.inv.service.repo;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import cams.inv.service.model.Order;
import cams.inv.service.model.OrderItem;
import cams.inv.service.model.Product;
import jakarta.transaction.Transactional;

/**
 * Order Repo Test CLass
 *
 */
@DataJpaTest
public class OrderRepositoryTest {

	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private OrderRepository orderRepository;

	@Test
	void testCreateOrder_Success() {
		Product product = new Product();
		product.setName("Laptop");
		product.setPrice(new BigDecimal("95000.00"));
		product.setSku("SKU123");
		product.setStock(10);
		productRepository.save(product);

		Order order = new Order();
		order.setOrderDate(LocalDateTime.now());
		OrderItem item = new OrderItem();
		item.setProduct(product);
		item.setQuantity(2);
		item.setOrder(order);
		order.getItems().add(item);

		orderRepository.save(order);

		List<Order> savedOrders = orderRepository.findAll();
		Assertions.assertEquals(1, savedOrders.size());
		Assertions.assertEquals(1, savedOrders.get(0).getItems().size());
	}

	@Test
	@Transactional
	void testRollback_WhenErrorOccurs() {
		Product product = new Product();
		product.setName("Laptop");
		product.setPrice(new BigDecimal("95000.00"));
		product.setSku("SKU123");
		product.setStock(10);
		productRepository.save(product);

		Assertions.assertThrows(Exception.class, () -> {
			Order order = new Order();
			order.setOrderDate(LocalDateTime.now());

			// this line throws error (null product)
			OrderItem invalidItem = new OrderItem();
			invalidItem.setProduct(null); // violates constraint
			invalidItem.setQuantity(2);
			invalidItem.setOrder(order);
			order.getItems().add(invalidItem);
			orderRepository.saveAndFlush(order);
		});

		Assertions.assertEquals(0, orderRepository.count());
	}

}
