package cams.inv.service.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;

import cams.inv.service.dto.OrderItemRequest;
import cams.inv.service.dto.OrderRequest;
import cams.inv.service.dto.OrderResponse;
import cams.inv.service.dto.OrderResponse.OrderItemResponse;
import cams.inv.service.exception.InsufficientStockException;
import cams.inv.service.global.exception.handler.GlobalExceptionHandler;
import cams.inv.service.svc.OrderService;

/**
 * Order Controller Test cases
 *
 */
@WebMvcTest(OrderController.class)
@Import(GlobalExceptionHandler.class)
public class OrderControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@MockitoBean
	private OrderService orderService;

	@Autowired
	private ObjectMapper objectMapper;

	@Test
	void createOrder_success() throws Exception {
		OrderRequest req = new OrderRequest(List.of(new OrderItemRequest("SKU123", 2)));
		OrderResponse resp = new OrderResponse(1L, LocalDateTime.now(), "COMPLETED",
				List.of(new OrderItemResponse(1L, "SKU1", "Item1", 2, BigDecimal.valueOf(50))),
				BigDecimal.valueOf(100));
		Mockito.when(orderService.create(Mockito.any())).thenReturn(resp);

		mockMvc.perform(post("/api/orders").contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(req))).andExpect(status().isCreated())
				.andExpect(jsonPath("$.status").value("COMPLETED")).andExpect(jsonPath("$.items[0].sku").value("SKU1"));
	}

	@Test
	//ValidationFailure case for create order
	void testCreateOrder_Failure() throws Exception {
		OrderRequest req = new OrderRequest(Collections.emptyList());
		mockMvc.perform(post("/api/orders").contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(req))).andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.items").value("must not be empty"));
	}

	@Test
	void testCreateOrder_InsufficientStock() throws Exception {
		OrderItemRequest item = new OrderItemRequest("SKU123", 10);
		OrderRequest req = new OrderRequest(List.of(item));
		Mockito.when(orderService.create(req))
				.thenThrow(new InsufficientStockException("Insufficient stock for SKU: SKU123"));

		mockMvc.perform(post("/api/orders").contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(req))).andExpect(status().isNotFound())
				.andExpect(jsonPath("$.Error").value("Insufficient stock for SKU: SKU123"));
	}

}
