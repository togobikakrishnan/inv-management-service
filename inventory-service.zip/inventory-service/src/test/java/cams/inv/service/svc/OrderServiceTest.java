package cams.inv.service.svc;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import cams.inv.service.constants.OrderStatus;
import cams.inv.service.dto.OrderItemRequest;
import cams.inv.service.dto.OrderRequest;
import cams.inv.service.dto.OrderResponse;
import cams.inv.service.dto.ProductSummary;
import cams.inv.service.exception.InsufficientStockException;
import cams.inv.service.exception.ResourceNotFoundException;
import cams.inv.service.model.Order;
import cams.inv.service.model.OrderItem;
import cams.inv.service.model.Product;
import cams.inv.service.repo.OrderRepository;
import cams.inv.service.repo.ProductRepository;

/**
 * Test class for Order Service
 *
 */
@ExtendWith(MockitoExtension.class)
public class OrderServiceTest {

	@Mock
	private OrderRepository orderRepository;

	@Mock
	private ProductRepository productRepository;

	@InjectMocks
	private OrderService orderService;

	@Test
	void testCreateOrder_Success() {
		Product product = new Product();
		product.setName("Laptop");
		product.setSku("SKU123");
		product.setPrice(new BigDecimal("1000.00"));
		product.setStock(10);
		OrderRequest req = new OrderRequest(List.of(new OrderItemRequest("SKU123", 2)));

		Mockito.when(productRepository.findBySku("SKU123")).thenReturn(Optional.of(product));
		Mockito.when(orderRepository.save(any(Order.class))).thenAnswer(i -> i.getArgument(0));

		OrderResponse order = orderService.create(req);

		Assertions.assertEquals(8, product.getStock());
		Assertions.assertEquals(1, order.items().size());
	}

	@Test
	// Creating an order in which the mentioned product is empty
	void testCreateOrder_Failure() {
		OrderRequest req = new OrderRequest(List.of(new OrderItemRequest("SKU999", 1)));

		Mockito.when(productRepository.findBySku("SKU999")).thenReturn(Optional.empty());

		Assertions.assertThrows(ResourceNotFoundException.class, () -> orderService.create(req));
	}

	@Test
	// Creating an order in which the mentioned product is having low stock
	void testCreateOrder_InsufficientStock() {
		Product product = new Product();
		product.setName("Laptop");
		product.setSku("SKU123");
		product.setPrice(new BigDecimal("1000.00"));
		product.setStock(3);
		OrderRequest req = new OrderRequest(List.of(new OrderItemRequest("SKU123", 5)));

		Mockito.when(productRepository.findBySku("SKU123")).thenReturn(Optional.of(product));

		assertThrows(InsufficientStockException.class, () -> orderService.create(req));
	}

	@Test
	void testSummarizeTotalPerProduct_Success() throws Exception {
		Product product = new Product();
		product.setName("Laptop");
		product.setSku("SKU123");
		product.setPrice(new BigDecimal("1000.00"));
		product.setStock(10);
		Order order = new Order();
		order.setId(1);
		order.setOrderDate(LocalDateTime.now());
		OrderItem item = new OrderItem();
		item.setId(2);
		item.setOrder(order);
		item.setProduct(product);
		item.setQuantity(3);
		order.getItems().add(item);
		order.setStatus(OrderStatus.COMPLETED);
		List<Order> list = new ArrayList<>();
		list.add(order);

		Mockito.when(orderRepository.findAll()).thenReturn(list);
		List<ProductSummary> summarizeTotalPerProduct = orderService.summarizeTotalPerProduct();
		Assertions.assertEquals(item.getQuantity() * product.getPrice().doubleValue(),
				summarizeTotalPerProduct.get(0).totalValue().doubleValue());
	}

}
