package cams.inv.service.repo;

import static org.assertj.core.api.Assertions.assertThat;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import cams.inv.service.model.Product;

/**
 * Product Repo Test class
 *
 */
@DataJpaTest
public class ProductRepositoryTest {

	@Autowired
	private ProductRepository productRepository;

	private Product product1;
	private Product product2;

	@BeforeEach
	void setup() {
		product1 = new Product();
		product1.setName("Mouse");
		product1.setSku("SKU123");
		product1.setPrice(new BigDecimal("1000.0"));
		product1.setStock(10);

		product2 = new Product();
		product2.setName("Keyboard");
		product2.setSku("SKU456");
		product2.setPrice(new BigDecimal("999.0"));
		product2.setStock(5);
		productRepository.saveAll(List.of(product1, product2));
	}

	@Test
	void testFindByName_Success() {
		Optional<List<Product>> result = productRepository.findByName("Keyboard");

		assertThat(result).isPresent();
		assertThat(result.get()).hasSize(1);
		assertThat(result.get().get(0).getName()).isEqualTo("Keyboard");
	}

	@Test
	void testFindByName_Failure() {
		Optional<List<Product>> result = productRepository.findByName("LapTop");

		assertThat(result).isEmpty();
	}

	@Test
	void testFindBySku_Success() {
		Optional<Product> result = productRepository.findBySku("SKU123");

		assertThat(result).isPresent();
		assertThat(result.get().getSku()).isEqualTo("SKU123");
		assertThat(result.get().getName()).isEqualTo("Mouse");
	}

	@Test
	void testFindBySku_Failure() {
		Optional<Product> result = productRepository.findBySku("SKU999");
		Assertions.assertEquals(result.isEmpty(), true);
	}

}
