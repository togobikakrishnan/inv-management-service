package cams.inv.service.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.math.BigDecimal;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;

import cams.inv.service.dto.ProductRequest;
import cams.inv.service.dto.ProductResponse;
import cams.inv.service.exception.ResourceNotFoundException;
import cams.inv.service.global.exception.handler.GlobalExceptionHandler;
import cams.inv.service.svc.ProductService;

/**
 * Product Controller TestCases
 *
 */
@WebMvcTest(ProductController.class)
@Import(GlobalExceptionHandler.class)
public class ProductControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@MockitoBean
	private ProductService productService;

	@Autowired
	private ObjectMapper objectMapper;

	// Product Creation Success Case
	@Test
	void testCreateProduct_SuccessCase() throws Exception {
		ProductRequest req = new ProductRequest("Laptop", "SKU123", BigDecimal.valueOf(1000), 10);
		ProductResponse resp = new ProductResponse(1L, "Laptop", "SKU123", BigDecimal.valueOf(1000), 10);
		Mockito.when(productService.create(Mockito.any())).thenReturn(resp);

		mockMvc.perform(post("/api/products").contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(req))).andExpect(status().isCreated())
				.andExpect(jsonPath("$.sku").value("SKU123"));
	}

	// List All Products Success Case
	@Test
	void testListAll() throws Exception {
		List<ProductResponse> list = List.of(new ProductResponse(1L, "Laptop", "SKU123", BigDecimal.valueOf(1000), 10),
				new ProductResponse(2L, "Phone", "SKU223", BigDecimal.valueOf(5000), 17));
		Mockito.when(productService.findAll()).thenReturn(list);

		mockMvc.perform(get("/api/products")).andExpect(status().isOk()).andExpect(jsonPath("$.length()").value(2))
				.andExpect(jsonPath("$[0].name").value("Laptop")).andExpect(jsonPath("$[1].sku").value("SKU223"));

	}

	// Validation Failure Case for Product attributes
	@Test
	void testCreateProduct_validationFailure() throws Exception {
		ProductRequest req = new ProductRequest("", "SKU123", BigDecimal.valueOf(-5), 10); // invalid input args

		mockMvc.perform(post("/api/products").contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(req))).andExpect(status().isBadRequest());
	}

	// Resource Not Found Case
	@Test
	void testGetProduct_NotFound() throws Exception {
		Mockito.when(productService.findBySku("SKU999"))
				.thenThrow(new ResourceNotFoundException("Product not found: SKU999"));

		mockMvc.perform(get("/api/products/SKU999")).andExpect(status().isNotFound())
				.andExpect(jsonPath("$.Error").value("Product not found: SKU999"));
	}

}
