package cams.inv.service.svc;

import static org.mockito.ArgumentMatchers.any;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import cams.inv.service.constants.InventoryConstants;
import cams.inv.service.dto.ProductRequest;
import cams.inv.service.dto.ProductResponse;
import cams.inv.service.exception.ResourceNotFoundException;
import cams.inv.service.model.Product;
import cams.inv.service.repo.ProductRepository;

@ExtendWith(MockitoExtension.class)
public class ProductServiceTest {

	@Mock
	private ProductRepository productRepository;

	@InjectMocks
	private ProductService productService;

	private Product product;

	private ProductRequest productReq;

	@BeforeEach
	void setup() {
		product = new Product();
		product.setId(1L);
		product.setName("Laptop");
		product.setSku("SKU123");
		product.setPrice(new BigDecimal("1000.0"));
		product.setStock(10);
		productReq = new ProductRequest("Laptop", "SKU123", new BigDecimal("1000.00"), 10);
	}

	@Test
	void testCreateProduce_Success() {
		Mockito.when(productRepository.save(any(Product.class))).thenAnswer(i -> i.getArgument(0));
		ProductResponse response = productService.create(productReq);
		Assertions.assertEquals(10, response.stock());
	}

	@Test
	void testFindAll_Success() {
		Mockito.when(productRepository.findAll()).thenReturn(List.of(product));

		List<ProductResponse> result = productService.findAll();

		Assertions.assertEquals(result.get(0).stock(), 10);
		Assertions.assertEquals(result.size(), 1);
	}

	@Test
	// Case when low stock is available
	void testFindLowStock_Success() {
		Product lowStockProduct = new Product();
		lowStockProduct.setId(2L);
		lowStockProduct.setName("LapTop");
		lowStockProduct.setSku("SKU456");
		lowStockProduct.setPrice(new BigDecimal("200000.0"));
		lowStockProduct.setStock(3);

		Mockito.when(productRepository.findAll()).thenReturn(Arrays.asList(product, lowStockProduct));

		List<ProductResponse> result = productService.findLowStock(5);

		Assertions.assertEquals(result.get(0).stock(), 3);
		Assertions.assertEquals(result.size(), 1);
	}

	@Test
	// Case when low stock is not available
	void testFindLowStock_Failure() {
		Mockito.when(productRepository.findAll()).thenReturn(List.of());

		List<ProductResponse> result = productService.findLowStock(5);

		Assertions.assertNull(result);
	}

	@Test
	// Update the existing product
	void testUpdate_Success() {
		Product product = new Product();
		product.setId(1L);
		product.setName("Laptop Pro");
		product.setSku("SKU123");
		product.setPrice(new BigDecimal(120099.0));
		product.setStock(8);

		ProductRequest updateReq = new ProductRequest("Laptop Pro", "SKU123", new BigDecimal(120099.0), 8);

		Mockito.when(productRepository.findBySku("SKU123")).thenReturn(Optional.of(product));
		Mockito.when(productRepository.save(any(Product.class))).thenReturn(product);

		ProductResponse response = productService.update(updateReq);

		Assertions.assertEquals(response.name(), "Laptop Pro");
		Assertions.assertEquals(response.price(), new BigDecimal(120099.0));
	}

	@Test
	// Updating product is not exists
	void testUpdate_Failure() {
		Mockito.when(productRepository.findBySku("SKU999")).thenReturn(Optional.empty());

		ProductRequest updateReq = new ProductRequest("Tablet", "SKU999", new BigDecimal(80970.0), 5);

		assertThatThrownBy(() -> productService.update(updateReq)).isInstanceOf(ResourceNotFoundException.class)
				.hasMessageContaining(InventoryConstants.PRODUCT_NOT_FOUND);
	}

}
